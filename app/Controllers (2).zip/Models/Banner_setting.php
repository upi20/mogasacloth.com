<?php
		
	namespace App\Models;

	use App\Core\ORMModel;

	Class Banner_setting extends ORMModel
	{
	}