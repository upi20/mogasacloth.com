<?php
		
	namespace App\Models;

	use App\Core\ORMModel;

	Class Menu extends ORMModel
	{
	}