<?php
		
	namespace App\Models;

	use App\Core\ORMModel;

	Class Role_menu extends ORMModel
	{
	}