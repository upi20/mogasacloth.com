<?php
		
	namespace App\Models;

	use App\Core\ORMModel;

	Class Web_setting extends ORMModel
	{
	}