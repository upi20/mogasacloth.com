<?php
		
	namespace App\Models;

	use App\Core\ORMModel;

	Class Testimonial extends ORMModel
	{
	}