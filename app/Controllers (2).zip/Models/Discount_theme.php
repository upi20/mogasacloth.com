<?php
		
	namespace App\Models;

	use App\Core\ORMModel;

	Class Discount_theme extends ORMModel
	{
	}