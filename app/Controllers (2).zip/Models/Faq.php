<?php
		
	namespace App\Models;

	use App\Core\ORMModel;

	Class Faq extends ORMModel
	{
	}