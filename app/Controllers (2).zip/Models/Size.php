<?php
		
	namespace App\Models;

	use App\Core\ORMModel;

	Class Size extends ORMModel
	{
	}