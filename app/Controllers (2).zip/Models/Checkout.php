<?php
		
	namespace App\Models;

	use App\Core\ORMModel;

	Class Checkout extends ORMModel
	{
	}