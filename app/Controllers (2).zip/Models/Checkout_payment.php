<?php
		
	namespace App\Models;

	use App\Core\ORMModel;

	Class Checkout_payment extends ORMModel
	{
	}