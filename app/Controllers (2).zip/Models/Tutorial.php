<?php
		
	namespace App\Models;

	use App\Core\ORMModel;

	Class Tutorial extends ORMModel
	{
	}