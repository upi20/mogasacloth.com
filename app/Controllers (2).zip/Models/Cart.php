<?php
		
	namespace App\Models;

	use App\Core\ORMModel;

	Class Cart extends ORMModel
	{
	}