<?php
		
	namespace App\Models;

	use App\Core\ORMModel;

	Class Slider_setting extends ORMModel
	{
	}