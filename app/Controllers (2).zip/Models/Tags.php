<?php
		
	namespace App\Models;

	use App\Core\ORMModel;

	Class Tags extends ORMModel
	{
	}