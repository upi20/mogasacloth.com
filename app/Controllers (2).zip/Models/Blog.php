<?php
		
	namespace App\Models;

	use App\Core\ORMModel;

	Class Blog extends ORMModel
	{
	}