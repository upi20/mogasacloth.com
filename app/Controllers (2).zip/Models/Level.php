<?php
		
	namespace App\Models;

	use App\Core\ORMModel;

	Class Level extends ORMModel
	{
	}