<?php
		
	namespace App\Models;

	use App\Core\ORMModel;

	Class Cart_detail extends ORMModel
	{
	}