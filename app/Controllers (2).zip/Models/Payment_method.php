<?php
		
	namespace App\Models;

	use App\Core\ORMModel;

	Class Payment_method extends ORMModel
	{
	}