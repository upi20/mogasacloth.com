<?php
		
	namespace App\Models;

	use App\Core\ORMModel;

	Class Bank_method extends ORMModel
	{
	}