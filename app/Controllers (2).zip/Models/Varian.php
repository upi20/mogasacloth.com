<?php
		
	namespace App\Models;

	use App\Core\ORMModel;

	Class Varian extends ORMModel
	{
	}