<?php
		
	namespace App\Models;

	use App\Core\ORMModel;

	Class Checkout_shipping extends ORMModel
	{
	}