<?php
		
	namespace App\Models;

	use App\Core\ORMModel;

	Class User extends ORMModel
	{
	}