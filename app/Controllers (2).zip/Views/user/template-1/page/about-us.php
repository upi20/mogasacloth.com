
<!-- breadcrumb -->
<div class="container">
	<div class="bread-crumb flex-w p-l-25 p-r-15 p-t-30 p-lr-0-lg">
		<a href="<?= base_url ?>" class="stext-109 cl8 hov-cl1 trans-04">
			Home
			<i class="fa fa-angle-right m-l-9 m-r-10" aria-hidden="true"></i>
		</a>

		<span class="stext-109 cl4">
			Tentang Kami
		</span>
	</div>
</div>

<!-- Product -->
<section class="bg0 p-t-75 p-b-120">
		<div class="container">
			
			<div class="row">
				<div class="order-md-2 col-md-7 col-lg-8 p-b-30">
					<div class="p-t-7 p-l-85 p-l-15-lg p-l-0-md">
						<h3 class="mtext-111 cl2 p-b-16">
							TENTANG Mogasacloth
						</h3>
						<h4>
							Bang Lombak<br>
							Direktur Mogasacloth
						</h4><br>
						<p class="stext-113 cl6 p-b-26">
Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
proident, sunt in culpa qui officia deserunt mollit anim id est laborum.”</i><br><br>


</p>

						<div class="p-l-29 p-b-9 m-t-22 text-center">
							<h3>Visi</h3>
							<p class="stext-114 cl6 p-r-40 p-b-11">
								Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.
							</p>ba
						</div>

						<div class="p-l-29 p-b-9 m-t-22 text-center">
							<h3>Misi</h3>
							<p class="stext-114 cl6 p-r-40 p-b-11">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.<br>
							</p>
						</div>
					</div>
				</div>

				<div class="order-md-1 col-11 col-md-5 col-lg-4 m-lr-auto p-b-30">
					<div class="how-bor2">
						<div class="hov-img0">
							<img src="https://mogasaclothing.infinit.id/website/configuration/1613372195logo-mogasa.png" alt="IMG">
						</div>
					</div>
				</div>
			</div>

		</div>
	</section>